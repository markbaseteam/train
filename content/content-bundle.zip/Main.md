<h1 style="text-align:center;">&#8595 &#8595 &#8595 Original text &#8595 &#8595 &#8595</h1>

![[TEXT_FINAL.txt]]

